﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.Models
{
    public class Admin
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AId { get; set; }

        [Required]
        public string AName { get; set; }

        [Required]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$", ErrorMessage = "Invalid Format.")]
        public string AEmail { get; set; }

        [Required]
        [MinLength(8, ErrorMessage = "Password must be at least 8 int long.")]
        [MaxLength(8, ErrorMessage = "Password must not exceed 8 int.")]
        [RegularExpression(@"^\d{8}$",
        ErrorMessage = "Please enter exactly 8 digits (numbers only). No characters are allowed.")]
        public int APassword { get; set; }

    }
}