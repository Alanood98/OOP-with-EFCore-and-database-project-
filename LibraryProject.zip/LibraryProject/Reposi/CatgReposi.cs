﻿using LibraryProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.Reposi
{
    public class CatgReposi
    {
        private readonly AppDB _context;

        public CatgReposi(AppDB context)
        {
            _context = context;
        }
        public IEnumerable<Category> GetAllCategory()
        {
            return _context.Categorise.ToList();
        }

        public IEnumerable<Category> GetCategoryByName(string CName)
        {
            return _context.Categorise
                    .Where(e => e.CName == CName)
                   .ToList();
        }

        public void InsertCategory(Category category)
        {
            _context.Categorise.Add(category);
            _context.SaveChanges();
        }

        public void UpdateCategoryByName(string Name)
        {
            var category = _context.Categorise.FirstOrDefault(c => c.CName == Name);
            if (category != null)
            {
                _context.Categorise.Update(category);
                _context.SaveChanges();
            }
        }

        public void DeleteCategoryById(int cid)
        {
            var category = _context.Categorise.Find(cid);
            if (category != null)
            {
                _context.Categorise.Remove(category);
                _context.SaveChanges();
            }
        }

        public void GetNumberOfBooks(int count) 
        {
            
        
        
        }

    }
}