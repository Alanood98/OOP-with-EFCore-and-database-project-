﻿using LibraryProject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.Reposi
{
    public class BorrowingReposi
    {
        private readonly AppDB _context;

        public BorrowingReposi(AppDB context)
        {
            _context = context;
        }

        public IEnumerable<Borrowing> GetAll()
        {
            return _context.Borrowings.ToList();
        }

        public IEnumerable<Borrowing> GetBorrowBookByName(string Bname)
        {
            return _context.Borrowings
                    .Include(e => e.Book)
                    .Where(e => e.Book.BName == Bname)
                    .ToList();
        }

        public void Insert(Borrowing borrow)
        {
            _context.Borrowings.Add(borrow);
            _context.SaveChanges();
        }

        public void UpdateBorrowingByBookName(string Name)
        {
            var borrow = _context.Borrowings.
                        Include(e => e.Book)
                        .FirstOrDefault(c => c.Book.BName == Name);
            if (borrow != null)
            {
                _context.Borrowings.Update(borrow);
                _context.SaveChanges();
            }
        }

        public void DeleteBorrowingById(int bid, int uid)
        {
            var borrow = _context.Borrowings.Find(bid, uid);
            if (borrow != null)
            {
                _context.Borrowings.Remove(borrow);
                _context.SaveChanges();
            }
        }


    }
}