﻿
using LibraryProject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.Reposi
{
    public class BookReposi
    {
        private readonly AppDB _context;

        public BookReposi(AppDB context)
        {
            _context = context;
        }
        public IEnumerable<Book> GetAllBooks()
        {
            return _context.Books.ToList();
        }

        public IEnumerable<Book> GetBookByName(string Bname)
        {
            return _context.Books
                    .Where(e => e.BName == Bname)
                   .ToList();
        }

        public void InsertBook(Book book)
        {
            _context.Books.Add(book);
            _context.SaveChanges();
        }

        public void UpdateBookByName(string Bname)
        {
            var book = _context.Books.FirstOrDefault(c => c.BName == Bname);
            if (book != null)
            {
                _context.Books.Update(book);
                _context.SaveChanges();
            }
        }

        public void DeleteBookById(int Bid)
        {
            var book = _context.Books.Find(Bid);
            if (book != null)
            {
                _context.Books.Remove(book);
                _context.SaveChanges();
            }
        }

        public double GetTotalPrice()
        {
            return _context.Books.Sum(b => b.Price);
        }

        public double getMaxPrice()
        {
            return _context.Books.Max(b => b.Price);
        }

        public int getTotalBorrowedBooks()
        {
            return _context.Books.Sum(b => b.BorrowedCopies);
        }

        public int getTotalBooksPerCategoryName(string Cname)
        {
            return _context.Books
                            .Where(b => b.Category.CName == Cname)
                            .Count();
        }

        public void updateCategoryCopyWhenDeleting(int Cid)
        {
            var catg = _context.Categorise.FirstOrDefault(b => b.CID == Cid);
            if (catg != null && catg.NumberOfBooks > 0)
            {
                catg.NumberOfBooks -= 1; // Decrement only if greater than 0
                _context.Categorise.Update(catg);
                _context.SaveChanges();
            }
        }

        public void updateCategoryCopyWhenAddingBook(int cid)
        {
            var catg = _context.Categorise.FirstOrDefault(b => b.CID == cid);
            if (catg != null)
            {
                catg.NumberOfBooks += 1; // Increment unconditionally
                _context.Categorise.Update(catg);
                _context.SaveChanges();
            }
        }

    }
}
