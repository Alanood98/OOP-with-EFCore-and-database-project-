﻿using LibraryProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static LibraryProject.Models.User;

namespace LibraryProject.Reposi
{
    public class UserReposi
    {
        private readonly AppDB _context;

        public UserReposi(AppDB context)
        {
            _context = context;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public IEnumerable<User> GetUserByName(string Uname)
        {
            return _context.Users
                    .Where(e => e.UName == Uname)
                   .ToList();
        }

        public void InsertUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public void UpdateCategoryByName(string Cname)
        {
            var user = _context.Users.FirstOrDefault(c => c.UName == Cname);
            if (user != null)
            {
                _context.Users.Update(user);
                _context.SaveChanges();
            }
        }

        public void DeleteUserById(int Uid)
        {
            var user = _context.Users.Find(Uid);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }
        public int countByGender(Gender gender)
        {
            return _context.Users.Count(u => u.gender == gender);
        }

        public IEnumerable<User> verifyUser(int pass)
        {
            return _context.Users
                    .Where(e => e.UPassword == pass)
                   .ToList();
        }



        public string RegisterUser(int password, string name, Gender gender)
        {
            // Check for duplicate passwords (assuming passcodes must be unique)
            var existingUser = _context.Users.FirstOrDefault(u => u.UPassword == password);
            if (existingUser != null)
            {
                return "This password is already in use. Please choose a different one.";
            }

            // Add the new user
            _context.Users.Add(new User
            {
                UName = name,
                UPassword = password,
                gender = gender
            });

            _context.SaveChanges();
            return "User registered successfully.";
        }





    }


}
